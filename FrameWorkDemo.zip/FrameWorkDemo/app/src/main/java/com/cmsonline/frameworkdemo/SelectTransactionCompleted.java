package com.cmsonline.frameworkdemo;

/**
 * Created by chris on 19/12/2017.
 */

public interface SelectTransactionCompleted {
    void transactionSelected(int position);


}
